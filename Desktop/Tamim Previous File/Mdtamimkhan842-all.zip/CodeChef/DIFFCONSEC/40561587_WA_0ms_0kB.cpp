#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t,i,j;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        int c=0;
        char s[n];
        for(i=1; i<=n; i++)
        {
            cin>>s[i];
        }
        for (j=1; j<=n; j++)
        {
            if(s[j] == s[j+1])
            {
                c++;
            }
        }
        cout<<c<<endl;
    }
}
