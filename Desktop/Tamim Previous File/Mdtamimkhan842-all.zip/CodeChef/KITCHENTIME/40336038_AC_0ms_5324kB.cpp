#include <bits/stdc++.h>
using namespace std;
int main ()
{
    int t, res;
    cin>>t;
    while(t--)
    {
        int x,y;
        cin>>x>>y;
        res = abs(x-y);
    cout<<res<<endl;
    }


}
