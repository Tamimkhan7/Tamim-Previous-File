#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;cin>>t;
    while(t--){
       int n;cin>>n;
       long long int ans =(n*1000)/100;
       cout<<ans<<'\n';
    }
}

