#include <bits/stdc++.h>
using namespace std;
#define ordered_set tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update>
#define faster                    \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);
#define mod 1000000007
typedef long long int ll;
typedef unsigned long long int llu;
int main()
{
    ll t;
    cin >> t;
    while (t--)
    {
        ll a, b, c, d;
        cin >> a >> b;
        c = a;
        d = b;
        if (d % c == 0)
        {
            cout << c << " ";
        }
        else
        {
            while (c != 0)
            {
                c = d % c;
                // b = a;
                d = c / d;
                if (d % c == 0)
                {
                    break;
                }
                else
                {
                    continue;
                }
            }
            cout << c << " ";
        }
        ll lcm = (a * b) / c;
        cout << lcm << endl;
    }
}
