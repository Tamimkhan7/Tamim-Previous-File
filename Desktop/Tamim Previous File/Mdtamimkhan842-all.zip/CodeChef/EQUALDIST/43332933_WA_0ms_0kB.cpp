#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, m, res;
        cin >> n >> m;
        if (n == m)
        {
            cout << "YES" << endl;
        }
        else if (n > m)
        {
            n--;
            m++;
            if (n == m)
                cout << "YES" << endl;
            else
                cout << "NO" << endl;
        }
        else
        {
            m--;
            n++;
            if (n == m)
                cout << "YES" << endl;
            else
                cout << "NO" << endl;
        }
    }
}