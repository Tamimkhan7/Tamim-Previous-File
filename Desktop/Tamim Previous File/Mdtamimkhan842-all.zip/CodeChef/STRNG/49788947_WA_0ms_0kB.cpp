#include <bits/stdc++.h>
using namespace std;
#define ordered_set tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update>
#define MTK                       \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);
typedef long long int ll;
#define all(x) x.begin(), x.end()
#define mod 1000000007
void solve()
{
    int n;
    cin >> n;
    vector<int> v(n);
    for (int i = 0; i < n; i++)
        cin >> v[i];
    int main_gcd = v[0], target_gcd;
    for (int i = 1; i < n; i++)
        main_gcd = __gcd(main_gcd, v[i]);
    int ans = 0;
    for (int i = 0; i < n; i++)
    {
        if (i == 0)
            target_gcd = v[1];
        else
            target_gcd = v[0];
        for (int j = 0; j < n; j++)
        {
            if (v[i] != v[j])            
                target_gcd = __gcd(target_gcd, v[j]);
            
        }
        // cout << main_gcd<<' target_gcd << '\n';
        if (target_gcd != main_gcd)
            ans++;
    }
    int cnt = 0, same_cnt=0;
    int x = v[0];
    for(int i=0; i<n; i++){
        if(x==v[i])
            same_cnt++;
    }  
    if (ans != 0 || same_cnt == n)
    {
        for (int i = 0; i < n; i++)
        {
            if (v[i] % 2 == 0)
                cnt = i;
        }
        cout << cnt + 1 << '\n';
        return;
        }
    cout << cnt << '\n';
}
int32_t main()
{
    MTK;
    int t;
    cin >> t;
    while (t--)
        solve();
}