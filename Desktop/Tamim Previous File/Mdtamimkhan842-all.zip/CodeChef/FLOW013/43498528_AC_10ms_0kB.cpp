#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int x, y, z;
        cin >> x >> y >> z;
        int k = x + y + z;
        if (k == 180)
            cout << "YES" << endl;
        else
            cout << "NO" << endl;
    }
}