#include <iostream>
using namespace std;
int main ()
{
    int T, N, i;
    cin>>T;
    for(i=1; i<=T; i++)
    {
        cin>>N;
        if (N%2==0)
        {
            cout<<"Yes";
        }
        else
        {
            cout<<"No";
        }
    }


    return 0;
}
