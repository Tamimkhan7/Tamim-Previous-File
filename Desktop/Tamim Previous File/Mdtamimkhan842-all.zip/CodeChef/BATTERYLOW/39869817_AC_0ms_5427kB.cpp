#include <iostream>
using namespace std;
int main ()
{
    int X,T, i;
    cin>>T;
    for (i=1; i<=T; i++)
    {
        cin>>X;
        if (X<=15)
        {
            cout<<"Yes"<<endl;
        }
        else
        {
            cout<<"No"<<endl;
        }
    }



    return 0;
}
