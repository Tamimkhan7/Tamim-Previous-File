#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin >> n;
    while (n--)
    {
        int k;
        cin >> k;
        if (k >= 2000)
            cout << "YES" << endl;
        else
            cout << "NO" << endl;
    }
}