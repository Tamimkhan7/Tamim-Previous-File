#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int x, y, z;
        cin >> x >> y >> z;
        int sum, sum2, sum3;
        sum = y + z;
        sum2 = x + z;
        sum3 = x + y;
        if (x == sum)
            cout << "YES" << endl;
        else if (y == sum2)
            cout << "YES" << endl;
        else if (z == sum3)
            cout << "YES" << endl;
        else
            cout << "NO" << endl;
    }
}