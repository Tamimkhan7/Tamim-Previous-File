#include <bits/stdc++.h>
using namespace std;
#define ordered_set tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update>
#define faster                    \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);
typedef long long int ll;
typedef unsigned long long int llu;
void solve()
{
}

int main()
{
    faster;
    int t;
    cin >> t;
    while (t--)
    {
        llu n, k;
        cin >> n >> k;
        cout << (n | (1u << k)) << endl;
    }
    return 0;
}