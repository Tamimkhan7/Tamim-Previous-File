#include <bits/stdc++.h>
using namespace std;
void solve()
{
    int n;
    cin>>n;
    int a[n];
    for(int i=0; i<n; i++)cin>>a[i];
    int ans=0;
    for(int i=0; i<n; i++)
    {
        for(int j=i; j<n; j++)
        {
            int product=1;
            for(int k=i; k<=j; k++)
            {
                product*=a[k];
            }
            //cout<<product<<endl;
            if(product)ans++;
        }
    }
     cout<<ans<<endl;

}
int main()
{
    int t;
    cin>>t;
    while(t--)solve();
}
