#include <bits/stdc++.h>
using namespace std;
const int N = 1e6+7;
int a[N];
int px[N];
#define ll long long
void solve()
{
    int n;
    cin>>n;
    int even=0, odd=0;
    for(int i=1; i<=n; i++)
    {
        if(i%2==0)even++;
        else odd++;
    }
    cout<<1LL*(odd*even)*2<<endl;
}
int main()
{
    int t;
    cin>>t;
    while(t--)solve();
}
