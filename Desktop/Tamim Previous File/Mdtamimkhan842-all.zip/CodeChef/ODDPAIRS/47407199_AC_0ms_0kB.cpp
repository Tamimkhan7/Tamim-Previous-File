#include <bits/stdc++.h>
using namespace std;
const int N = 1e6+7;
int a[N];
int px[N];
#define ll long long
void solve()
{
    int n;
    cin>>n;
    cout<<1LL*n*n/2<<'\n';
}
int main()
{
    int t;
    cin>>t;
    while(t--)solve();
}
