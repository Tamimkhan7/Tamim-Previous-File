#include <bits/stdc++.h>
using namespace std;
#define ll long long
const ll mod = 1e9+7;

int main()
{
    int t;cin>>t;
    while(t--){
        int n;cin>>n;
        int even=0, odd=0;
        for(int i=1; i<=n;i++){
            if(i%2==0)even++;
            else odd++;
        }
        ll res = odd*(even*2);
        cout<<res<<'\n';
    }
}



