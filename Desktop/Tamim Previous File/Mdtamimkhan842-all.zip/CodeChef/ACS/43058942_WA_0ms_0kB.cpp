#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int a;
        cin >> a;
        if (a <= 10)
        {
            cout << a << endl;
        }
        else if (a <= 99 && a % 10 < 10)
        {
            int b = a / 10;
            int c = a % 10;
            cout << b + c << endl;
        }
        else if (a >= 100 && a % 100 < 10)
        {
            int b = a / 100;
            int c = a % 100;
            cout << b + c << endl;
        }
        else
        {
            cout << -1 << endl;
        }
    }
}