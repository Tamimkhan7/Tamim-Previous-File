#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int a, res;
        cin >> a;
        if (a <= 10)
        {
            cout << a << endl;
        }
        else if (a < 100)
        {
            int b = a / 10;
            int c = a % 10;
            res = b + c;
            if (res <= 10)
            {
                cout << res << endl;
            }
            else
            {
                cout << -1 << endl;
            }
        }
        else
        {
            int b = a / 100;
            int c = a % 100;
            res = b + c;
            if (res <= 10)
            {
                cout << res << endl;
            }
            else
            {
                cout << -1 << endl;
            }
        }
        // else
        // {
        //     cout << -1 << endl;
        // }
    }
}