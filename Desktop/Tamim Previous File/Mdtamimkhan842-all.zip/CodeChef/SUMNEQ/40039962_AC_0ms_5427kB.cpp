#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int k = n-1;
    cout<<k<<endl;
    return 0;
}
