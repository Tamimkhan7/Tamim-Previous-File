#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
       int x,y;cin>>x>>y;
       int ans = x+y;
       int res1= 500-x*2;
       int res2= 1000-ans*4;
       int ans1= res1+res2;
       int res3= 500-ans*2;
       int res4= 1000-y*4;
       int ans2= res3+res4;
       cout<<max(ans1, ans2)<<'\n';

    }

}
