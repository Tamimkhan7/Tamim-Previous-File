#include <bits/stdc++.h>
using namespace std;
int main()
{
    int x;
    double y;
    cin>>x;
    cin>>y;
    double n = x+0.50;
    if (x%5==0)
    {
        double k = y-x;
        double m = k-0.5;
        cout<<m<<endl;
    }
    else if (x<y)
    {
        cout<<y<<endl;
    }


    return 0;
}
