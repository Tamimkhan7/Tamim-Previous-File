#include <bits/stdc++.h>
using namespace std;
int main(){
    int c;cin >> c;
    cout << c << endl;
    }