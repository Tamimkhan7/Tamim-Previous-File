#include <iostream>

using namespace std;

int main() {
    // Get input from the user
    double A, B;
    char C;

    cin >> A >> B >> C;

    // Perform the calculation based on the operator
    double result;
    if (C == '+') {
        result = A + B;
    } else if (C == '-') {
        result = A - B;
    } else if (C == '*') {
        result = A * B;
    } else if (C == '/') {
        result = A / B;
    } else {
        cout << "Invalid operator" << endl;
        return 0;
    }

    // Print the result
    cout << fixed;
    cout.precision(6);
    cout << result << endl;

    return 0;
}
