#include <bits/stdc++.h>
using namespace std;
int main()
{
    int a, b;
    char input;
    cin >> a >> b;
    cin >> input;

    if (input == '+')
    {
        cout << a + b << endl;
    }
    else if (input == '-')
    {
        cout << a - b << endl;
    }
    else if (input == '*')
    {
        cout << a * b << endl;
    }
    else if (input == '/')
    {
        double res = (double)a / (double)b;
        printf("%0.1f", res);
    }
}