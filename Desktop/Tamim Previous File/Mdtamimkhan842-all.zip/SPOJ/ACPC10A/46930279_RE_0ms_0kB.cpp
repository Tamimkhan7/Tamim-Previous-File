#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define mod 1000000007
void solve()
{

}
int main()
{
    int a,b,c;
    while(cin>>a>>b>>c)
    {
        int ans = b-a;
        int ans2 = c-b;
        int res = b/a;
        int res2 = c/b;
        if(a==0 && b==0 && c==0)return 0;
        else if(ans==ans2)
        {
            cout<<"AP "<<c+ans<<endl;
            continue;
        }
        else if(res==res2)
        {
            cout<<"GP "<<c*res<<endl;
            continue;
        }
    }
}
