#include <bits/stdc++.h>
using namespace std;

#define ordered_set tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update>
#define MTK                       \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);
typedef long long int ll;

void solve()
{
    string s, a, b;
    cin >> s >> a >> b;
    int n = s.size(), x = a.size();
    int j = 0;

    while (j < x)
    {
        if (a[j] == b[j])
            j++;
        else if (a[j] > b[j])
        {
            cout << ">" << '\n';
            return;
        }
        else if (a[j] < b[j])
        {
            cout << "<" << '\n';
            return;
        }
    }
    cout << "=" << '\n';
}

int32_t main()
{
    MTK;
    int t;
    cin >> t;

    while (t--)
        solve();
}
