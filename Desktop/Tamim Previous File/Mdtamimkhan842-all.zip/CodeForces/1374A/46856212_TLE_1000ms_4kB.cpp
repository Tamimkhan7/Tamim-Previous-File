#include<bits/stdc++.h>
using namespace std;
#define ll long long int
void solve()
{
    int x,y,n;cin>>x>>y>>n;
    for(int i=n; i>=0; i--)
    {
        if(i%x==y)
        {
            cout<<i<<endl;
            return;
        }
    }
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        solve();
    }

}
