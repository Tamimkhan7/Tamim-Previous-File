#include <bits/stdc++.h>
using namespace std;
#define maxNUm 999999999
#define ll long long int
int main()
{
    int n;
    cin >> n;
    vector<int> v(n);
    for (int i = 0; i < n; i++)
        cin >> v[i];

    ll sum = 0;
    for (int i = 0; i < n; i++)
        sum += v[i];

    int c = 0;
    for (int i = 0; i < n - 1; i++)
    {
        if (v[i] == v[i + 1])
            c++;
    }
    if (c == n - 1)
        cout << sum - v[n - 1] << endl;
    else
        cout << sum << endl;
}