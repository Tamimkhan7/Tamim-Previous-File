#include <bits/stdc++.h>
using namespace std;
#define maxNUm 999999999
#define ll long long int
int main()
{
    int n;
    cin >> n;
    vector<int> v(n);
    for (int i = 0; i < n; i++)
        cin >> v[i];

    ll sum = 0;
    for (int i = 0; i < n; i++)
        sum += v[i];
    sort(v.begin(), v.end());
    for (int i = 0; i < n; i++)
    {
        if (sum % 2 == 0)
            break;
        else
            sum -= v[i];
    }
    cout << sum << endl;
}