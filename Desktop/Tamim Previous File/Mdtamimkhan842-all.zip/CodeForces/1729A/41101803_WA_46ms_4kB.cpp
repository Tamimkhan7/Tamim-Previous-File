#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int a,b,c;
        cin>>a>>b>>c;
        int res = abs(c-b)+c;
        if(a==1)
        {
            cout<<"1"<<endl;
        }
        else if(a==res)
        {
            cout<<"3"<<endl;
        }
        else if(a>res)
        {
            cout<<"2"<<endl;
        }
    }

}
