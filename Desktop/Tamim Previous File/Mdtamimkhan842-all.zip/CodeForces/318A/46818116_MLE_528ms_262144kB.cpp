#include <bits/stdc++.h>
using namespace std;
#define ll long long
int main()
{
    ll n,k;
    cin>>n>>k;
    vector<ll>v;
    for(ll i=1; i<=n; i+=2)
    {
        v.push_back(i);
    }
    for(int i=2; i<=n; i+=2)
    {
        v.push_back(i);
    }

    cout<<v[k-1]<<endl;
}
