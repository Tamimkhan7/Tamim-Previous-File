#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int i, k;
        string s, ss;
        cin >> s;
        k = s.size();
        for (int i = 0; i < k; i++)
        {
            ss += tolower(s[i]);
        }

        int c = 0;
        for (i = 0; i < k; i++)
        {

            if (ss[i] == 'y' || ss[i] == 'e' || ss[i] == 's')
            {
                c++;
            }
        }
        if (c == 3)
            cout << "YES" << endl;
        else
            cout << "NO" << endl;
    }
}