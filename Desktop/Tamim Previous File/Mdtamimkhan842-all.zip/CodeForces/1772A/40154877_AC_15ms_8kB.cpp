#include <bits/stdc++.h>
using namespace std;
int main ()
{
    int t, a,b, sum;
    cin>>t;
    for (int i=1; i<=t; i++)
    {
        cin>>a>>b;
        sum = a+b;
        cout<<sum<<endl;
    }

    return 0;
}
