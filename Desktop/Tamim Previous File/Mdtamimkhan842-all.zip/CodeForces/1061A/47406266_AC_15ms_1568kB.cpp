#include <bits/stdc++.h>
using namespace std;
const int N = 2e5+9;
int a[N], pre[N];
int main()
{
    int n,s;
    cin>>n>>s;
  int ans = (s+n-1)/n;//ceil function ar kaj kore,
    cout<<ans<<'\n';
}
