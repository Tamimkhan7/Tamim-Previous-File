#include <bits/stdc++.h>
using namespace std;
#define ll long long int
#define mod 1073741824
const int N = 1e7+7;
int a[N];
void solve()
{
}
int find_value(int n)
{
    return a[n];
}
int main()
{

    for(int i=1; i<N; i++)
    {
        for(int j=i; j<N; j+=i)
        {
            a[j]++;
        }
    }

    ll sum =0,x;
    int a,b,c;

    cin>>a>>b>>c;
    for(int i=1; i<=a; i++)
    {
        for(int j=1; j<=b; j++)
        {
            for(int k=1; k<=c; k++)
            {
                x = i*j*k;
                sum += (find_value(x))%mod;
            }
        }
    }

    cout<<sum<<endl;
}
