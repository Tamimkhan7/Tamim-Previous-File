#include<bits/stdc++.h>
using namespace std;
void solve()
{
    int a,b,x;
    cin>>a>>b;
    if(a%b==0)
    {
        cout<<0<<endl;
        return;
    }
    int ans=0;
    while(a!=b)
    {
        if(a<b)
        {
            ans++;
            x = abs(a-b);
            if(x>=10)
            {
                a+=10;
            }
            else
            {
                a+=x;
            }
        }
        else
        {
            ans++;
            x =abs( a-b);
            if(x>=10)
                a-=10;
            else
            {
                a-=x;
            }
        }
    }
    cout<<ans<<endl;

}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        solve();
    }
}
