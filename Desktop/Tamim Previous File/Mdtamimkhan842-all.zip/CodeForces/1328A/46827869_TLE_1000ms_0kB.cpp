#include <bits/stdc++.h>
using namespace std;
void solve()
{
    int a,b;
    cin>>a>>b;

    if(a%b==0)
    {
        cout<<0<<endl;
        return;
    }
    int ans =0;
    while(1)
    {
        a++;
        ans++;
        if(a%b==0)
        {
            cout<<ans<<endl;
            return;
        }
    }
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        solve();
    }
}
