#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, c = 0;
        cin >> n;
        if (n <= 10)
        {
            cout << n << endl;
        }
        else
        {
            for (int i = 1; i <= n; i++)
            {
                if (i <= 100)
                {
                    if (i % 10 == 0)
                        c++;
                }
                else if (i <= 1000)
                {
                    if (i % 100 == 0)
                        c++;
                }
                else if (i <= 10000)
                {
                    if (i % 1000 == 0)
                        c++;
                }
                else
                {
                    if (i % 10000 == 0)
                        c++;
                }
            }
            cout << c + 9 << endl;
        }
    }
}