#include <bits/stdc++.h>
using namespace std;
#define ordered_set tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update>
#define MTK                       \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);
typedef long long int ll;
#define all(x) x.begin(), x.end()
#define mod 1000000007
int n;
string s;
void subarray()
{
    string ans;
    int flag = 0;
    vector<string> v;
    for (int i = 0; i < s.size(); i++)
    {
        for (int j = 0; j < s.size(); j++)
        {
            string ss;
            for (int k = i; k <= j; k++)
                ss += s[k];
            if ((ss.size() >= 2) and find(v.begin(), v.end(), ss) != v.end())
            {
                ans = ss;
                // cout << ans << '\n';
                flag = 1;
                break;
            }
            v.push_back(ss);
        }
        if (flag == 1)
            break;
    }
    int cnt = 0, to = 0;
    if (ans[0] == ans[1])
    {
        char x = ans[0];
        for (int i = 0; i < s.size(); i++)
        {
            if (x == s[i])
                cnt++;
            else
            {
                if (cnt == 3)
                    to++;

                cnt = 0;
            }
        }
    }
    if (cnt == 3)
        to++;
    if (to == 1)
    {
        cout << "NO" << '\n';
        return;
    }
    if (ans.size() >= 2)
        cout << "YES" << '\n';
    else
        cout << "NO" << '\n';
}
void solve()
{
    cin >> n >> s;
    subarray();
}
int32_t main()
{
    MTK;
    int t;
    cin >> t;
    while (t--)
        solve();
}