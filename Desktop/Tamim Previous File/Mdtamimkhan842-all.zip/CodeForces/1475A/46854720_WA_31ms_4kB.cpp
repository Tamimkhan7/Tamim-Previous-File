#include<bits/stdc++.h>
using namespace std;
void solve()
{
    long long int n;
    cin>>n;

    if(n%2)
        cout<<"YES"<<endl;
    else
        cout<<"NO"<<endl;
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        solve();
    }
}
