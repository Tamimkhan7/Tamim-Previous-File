#include<bits/stdc++.h>
using namespace std;
void solve()
{
    long long int n;
    cin>>n;
    if(n&(n-1)!=0)
        cout<<"YES"<<endl;
    else
        cout<<"NO"<<endl;
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        solve();
    }

}
