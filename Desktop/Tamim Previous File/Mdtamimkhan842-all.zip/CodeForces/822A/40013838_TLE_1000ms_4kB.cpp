#include <bits/stdc++.h>
using namespace std;
int main ()
{
    long long int a,b;
    long long int i,j;
    cin>>a>>b;
    long long int fact2 =1;
    long long int fact1 =1;
    for ( i=1; i<=a; i++)
    {
        fact2 = fact2*i;
    }
    for ( j=1; j<=b; j++)
    {
        fact1 = fact1*j;
    }
    if(fact2>fact1)
    {
        cout<<fact1<<endl;
    }
    else
    {
        cout<<fact2<<endl;
    }

    return 0;
}
