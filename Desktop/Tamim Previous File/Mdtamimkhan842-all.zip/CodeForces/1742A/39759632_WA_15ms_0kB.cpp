#include <iostream>
using namespace std;
int main ()
{
    int t, A, B,C, i, result;
    cin>>t;
    for (i=1; i<=t; i++)
    {
        cin>>A>>B>>C;
        result = A+B+C;
        if (result % 2==0 || result ==0)
        {
            cout<<"YES"<<endl;
        }
        else
        {
            cout<<"NO"<<endl;
        }
    }



    return 0;
}
