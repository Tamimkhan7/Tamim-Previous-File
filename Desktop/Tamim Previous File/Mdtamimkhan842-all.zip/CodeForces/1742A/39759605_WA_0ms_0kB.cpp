#include <iostream>
using namespace std;
int main ()
{
    int T, A, B,C, i, result;
    cin>>T;
    for (i=1; i<=T; i++)
    {
        cin>>A>>B>>C;
        result = A+B+C;
        if (result % 2==0)
        {
            cout<<"Yes"<<endl;
        }
        else
        {
            cout<<"No"<<endl;
        }
    }



    return 0;
}
