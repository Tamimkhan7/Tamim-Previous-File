#include <bits/stdc++.h>
using namespace std;
int main()
{
    long long int n,sum=0,sum2=0,i,res, res2;
    cin>>n;
    for (i=1; i<=n; i++)
    {
        if(i%2)sum2+=i;
        else sum +=i;
    }
    if(sum2>sum)cout<<(sum-abs(sum2))<<endl;
    else cout<<sum-sum2<<endl;
    return 0;
}
