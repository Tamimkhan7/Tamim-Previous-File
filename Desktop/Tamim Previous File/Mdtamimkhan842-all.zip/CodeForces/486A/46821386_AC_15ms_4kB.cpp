#include <bits/stdc++.h>
using namespace std;
int main()
{
    long long int n,sum=0,sum2=0,i,res, res2;
    cin>>n;
   if(n%2==0)cout<<n/2<<endl;
   else cout<<n/2-n<<endl;
    return 0;
}
