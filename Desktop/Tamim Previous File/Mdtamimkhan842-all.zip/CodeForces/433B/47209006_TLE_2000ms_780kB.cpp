#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin>>n;
    int a[n],b[n];
    for(int j=0; j<n; j++)
    {
        cin>>a[j];
        b[j]=a[j];
    }

    int x;
    cin>>x;
    while(x--)
    {
        int m, l,r;
        cin>>m>>l>>r;
        l--, r--;
        long long ans =0;
        if(m==1)
        {
            for(int i=l; i<=r; i++)ans +=a[i];
        }
        else
        {
            sort(b, b+n);
            for(int i=l; i<=r; i++)ans +=b[i];
        }
        cout<<ans<<'\n';
    }

}
