#include <bits/stdc++.h>
using namespace std;
const int N = 2e5+9;
int a[N], pre[N];
int main()
{
   int  t;cin>>t;
   while(t--){
    int n;cin>>n;
    cout<<n<<" ";
    for(int i=1; i<n; i++)cout<<i<<" ";
    cout<<'\n';
   }
}
