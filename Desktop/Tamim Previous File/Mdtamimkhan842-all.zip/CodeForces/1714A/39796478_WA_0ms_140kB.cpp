
#include <bits/stdc++.h>

using namespace std;

int main()
{

    int t;
    cin >> t;

    while (t--)
    {
        int a, b, c;
        cin >> a >> b >> c;

        vector < pair < int, int > > v(a);

        for (int i = 0; i < a; i++)
        {
            int x, y;
            cin >> x >> y;
            v[i] = {x, y};
        }

        sort(v.begin(), v.end());

        pair < int, int > next_alarm = {v[0].first, v[0].second};

        if (next_alarm.first == b && next_alarm.second == c)
        {
            cout << 0 << " " << 0 << "\n";
        }
        else
        {
            int mn = 60 - c;
            if (c == 60) mn = next_alarm.second;
            else mn = (60 - c) + next_alarm.second;

            int hour = 0;

            if (b == 23) hour = next_alarm.first;
            else hour = next_alarm.first - (b+1);

            if (mn > 60) {
                hour++;
                mn -= 60;
            }

            cout << hour << " " << mn << "\n";
        }
    }
}
