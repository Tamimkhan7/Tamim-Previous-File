#include <bits/stdc++.h>
using namespace std;
#define ll long long int
const int N=1e5+5;
int px[N];

void solve()
{
    int n,k;
    cin>>n>>k;
    int a[k+1], p[n+1];
    for(int i=n-k+1; i<=n; i++)cin>>a[i];
    if(k==1){
        cout<<"YES"<<endl;
        return;
    }
    for(int i=n-k+2; i<=n;i++){
        p[i]= a[i]-a[i-1];
    }


    if(a[n-k+1]>1LL*p[n-k+2]*(n-k+1))
    {
        cout<<"NO"<<'\n';
        return;
    }
    cout<<"YES"<<'\n';

}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        solve();
    }
}

