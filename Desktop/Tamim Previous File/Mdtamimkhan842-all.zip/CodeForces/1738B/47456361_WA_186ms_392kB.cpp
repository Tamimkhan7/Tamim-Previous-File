#include <bits/stdc++.h>
using namespace std;
#define ll long long int
const int N=1e5+5;
int px[N];

void solve()
{
    int n,k;
    cin>>n>>k;
    int a[k+1], p[n+1];
    for(int i=1; i<=k; i++)cin>>a[i];
    int x = a[2]-a[1];
    if(a[1]>1LL*x*(n-k+1))
    {
        cout<<"NO"<<'\n';
        return;
    }
    cout<<"YES"<<'\n';

}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        solve();
    }
}

