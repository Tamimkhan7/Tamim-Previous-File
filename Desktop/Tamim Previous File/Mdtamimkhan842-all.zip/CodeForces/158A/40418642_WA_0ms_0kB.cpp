#include <bits/stdc++.h>
using namespace std;
int main()
{
    int a,b,m,res,i;
    cin>>a;
    cin>>b;
    int k[a];
    for(i=0; i<a; i++)
    {
        cin>>k[i];
    }
    m += k[b];

//cout<<m<<endl;
    if(b<=m)
    {
        res = (m-1);
        cout<<res<<endl;
    }
    else
    {
        cout<<0<<endl;
    }
}
