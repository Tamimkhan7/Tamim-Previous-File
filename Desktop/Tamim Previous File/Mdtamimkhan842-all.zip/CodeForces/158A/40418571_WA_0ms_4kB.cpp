#include <bits/stdc++.h>
using namespace std;
int main()
{
    int a,b,m,res;
    cin>>a;
    cin>>b;
    int k[a];
    for(int i=1; i<=a; i++)
    {
        cin>>k[i];
    }
    m += k[b];
    if(m == 0)
    {
        cout<<0<<endl;
    }
    else
    {
        res = abs(m-1);
        cout<<res<<endl;
    }
}
