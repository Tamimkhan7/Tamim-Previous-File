#include <bits/stdc++.h>
using namespace std;
const int N = 1e9+9;
void solve()
{
    int n;
    cin>>n;
    int x =n;
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            int gcd = __gcd(i,j);
            int lcm = (i*j)/gcd;
            if(gcd+lcm==x)
            {
                cout<<i<<" "<<j<<'\n';
                return ;
            }
        }
    }
}
int main()
{
    int  t;
    cin>>t;
    while(t--)
    {
        solve();
    }
}
