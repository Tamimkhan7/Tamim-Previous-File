#include <bits/stdc++.h>
using namespace std;
int main()
{
    int a, b, c;
    cin >> a >> b >> c;
    int k, n, m, l;
    k = a + b * c;
    n = a * (b + c);
    m = a * b * c;
    l = (a + b) * c;
    if (k >= n && k >= m && k >= l)
    {
        cout << k << endl;
    }
    if (n >= k && n >= m && n >= l)
    {
        cout << n << endl;
    }
    if (m >= n && m >= n && m >= l)
    {
        cout << m << endl;
    }
    else
        cout << l << endl;
}