#include <bits/stdc++.h>
using namespace std;
int main()
{
    int a, b, c;
    cin >> a >> b >> c;
    int k, n, m, l, p, q;
    k = a * b * c;
    n = a + b + c;
    m = (a + b) * c;
    l = (a + c) * b;
    p = (a * b) + c;
    q = (a * c) + b;
    if (k > n && k > m && k > l && k > p && k > q)
    {
        cout << k << endl;
    }
    else if (n > k && n > m && n > l && n > p && n > q)
    {
        cout << n << endl;
    }
    else if (m > n && m > k && m > l && m > p && m > q)
    {
        cout << m << endl;
    }
    else if (l > n && l > m && l > k && l > p && l > q)
    {
        cout << l << endl;
    }
    else if (q > n && q > m && q > k && q > p && q > l)
    {
        cout << q << endl;
    }
    else
    {
        cout << p << endl;
    }
}