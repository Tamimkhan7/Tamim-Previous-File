#include <bits/stdc++.h>
using namespace std;
int main()
{
    int a, b, c;
    cin >> a >> b >> c;
    int k, n, m, l;
    k = a + b * c;
    n = a * (b + c);
    m = a * b * c;
    l = (a + b) * c;
    if (k > n && k > m && k > l)
    {
        cout << k << endl;
    }
    else if (n > k && n > m && n > l)
    {
        cout << n << endl;
    }
    else if (m > n && m > k && m > l)
    {
        cout << m << endl;
    }
    else if (l > n && l > m && l > k)
    {
        cout << l << endl;
    }
}