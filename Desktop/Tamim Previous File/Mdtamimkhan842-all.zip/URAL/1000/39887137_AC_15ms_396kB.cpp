#include <bits/stdc++.h>
using namespace std;
int main ()
{
    int a, b;
    cin>>a>>b;
    int sum1 = a+b;
    cout<<sum1<<endl;

    return 0;
}
