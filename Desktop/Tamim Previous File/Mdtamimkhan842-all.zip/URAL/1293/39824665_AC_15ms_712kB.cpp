#include <iostream>
using namespace std;
int main ()
{
    int N, A, B;
    cin>>N>>A>>B;
    int result = 2*(N*A*B);
    cout<<result<<endl;


    return 0;
}
