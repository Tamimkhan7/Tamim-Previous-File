#include <bits/stdc++.h>
using namespace std;
int main ()
{
    int a, b;
    cin>>a>>b;
    int result = a-1;
    int result1 = b-1;
    cout<<result1<<" "<<result<<endl;


    return 0;
}
