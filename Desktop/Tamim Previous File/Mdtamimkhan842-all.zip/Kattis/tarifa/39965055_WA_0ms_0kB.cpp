#include <bits/stdc++.h>
using namespace std;
int main ()
{
    int x, n, p, sum =0, result;
    cin>>x>>n;
    for (int i = 1; i<=n; i++)
    {
        cin>>p;
        //cout<<endl;
        int sum = sum + p;
        //cout<<sum<<endl;
        result = ((x*n)+x)-sum;
    }
        cout<<result<<endl;

    return 0;
}
