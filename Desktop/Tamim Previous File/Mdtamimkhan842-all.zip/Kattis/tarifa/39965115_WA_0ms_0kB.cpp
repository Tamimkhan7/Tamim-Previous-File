#include <bits/stdc++.h>
using namespace std;
int main ()
{
    int X,N,P, sum =0, result;
    cin>>X;
    cin>>N;
    for (int i = 1; i<=N; i++)
    {
        cin>>P;
        //cout<<endl;
        int sum = sum + P;
        //cout<<sum<<endl;
        result = ((X*N)+X)-sum;
    }
        cout<<result<<endl;

    return 0;
}
