#include <bits/stdc++.h>
using namespace std;
int main()
{
    double a,b;
    cin>>a>>b;
    double sum = 0.5*a*b;
    cout<<sum<<endl;
}
