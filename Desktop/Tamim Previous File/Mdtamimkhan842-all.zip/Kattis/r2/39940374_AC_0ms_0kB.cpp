#include <bits/stdc++.h>
using namespace std;
int main ()
{
    int r1, r2, s;
    cin>>r1>>s;
    r2 = s*2-r1;
    cout<<r2<<endl;

    return 0;
}
