#include <bits/stdc++.h>
using namespace std;
int main ()
{
    int a,b;
    cin>>a>>b;
    int result = 2*a+100;
    int result2 = result-b;
    cout<<result2<<endl;

    return 0;
}
