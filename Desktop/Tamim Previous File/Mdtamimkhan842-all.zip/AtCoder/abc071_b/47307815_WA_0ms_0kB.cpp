#include <bits/stdc++.h>
using namespace std;
#define ll long long int

int main()
{
    string s,c;
    cin>>s;
    int n = s.size();
    sort(s.begin(), s.end());
    int x,y;
    int flag =0;
    for(int i=1; i<n; i++)
    {
        x = s[i]-'a';
        y = s[i-1]-'a';
        //cout<<x<<" "<<y<<endl;
        if(abs(y-x)>1)
        {
            flag=1;
            c = s[i-1]+1;
            cout<<c<<'\n';
            return 0;
        }
    }
    int p = s[0]- 'a';
    if(p!=0 && n==1)
    {
        cout<<"a"<<endl;
        return 0;
    }
    else if(!flag)
    {
        cout<<"None"<<'\n';
    }
}
