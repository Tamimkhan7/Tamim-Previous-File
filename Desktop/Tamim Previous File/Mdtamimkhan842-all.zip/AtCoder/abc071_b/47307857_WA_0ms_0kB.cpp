#include <bits/stdc++.h>
using namespace std;
#define ll long long int
int px[26];
int main()
{
    string s,c;
    memset(px, 0, sizeof(px));
    cin>>s;
    int n = s.size();
    for(int i=0; i<n; i++){
        px[s[i]-'a']++;
    }
    for(int i=0; i<n; i++){
       if(px[i]==0){
        cout<<(char)(i+'a')<<'\n';
        return 0;
       }
    }
    cout<<"None"<<'\n';
    return 0;

}
