#include <bits/stdc++.h>
using namespace std;
int main ()
{
int a, b, h;
cin>>a>>b>>h;
int result = (a+b)*(h/2);
cout<<result<<endl;

return 0;
}
