#include <bits/stdc++.h>
using namespace std;
int main ()
{
    int a,b, result;
    cin>>a>>b;
    result = a+b;
    if (result >= 10)
    {
        cout<<"error"<<endl;
    }
    else
    {
        cout<<result<<endl;
    }


    return 0;
}
