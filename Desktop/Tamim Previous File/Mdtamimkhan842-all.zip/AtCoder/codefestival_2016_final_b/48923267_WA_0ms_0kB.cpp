#include <bits/stdc++.h>
using namespace std;

int32_t main()
{
   
    int n;
    cin >> n;
    if (n == 1)
        cout << n << '\n';
    else if (n % 2 == 0)
    {
        cout << n / 2 - 1 << '\n';
        cout << n / 2 + 1 << '\n';
    }
    else
    {
        cout << n / 2 << '\n';
        cout << n / 2 + 1 << '\n';
    }
}