#include <bits/stdc++.h>
using namespace std;
int main ()
{
    int t,c=0;
    cin>>t;
    int arr[t];
    int p;
    cin>>p;
    for (int i=1; i<=t; i++)
    {
        cin>>arr[i];
    }
    for (int j=1; j<=t; j++)
    {
        if (arr[j]<p)
        {
            c++;
        }
    }
    cout<<c<<endl;





    return 0;
}
