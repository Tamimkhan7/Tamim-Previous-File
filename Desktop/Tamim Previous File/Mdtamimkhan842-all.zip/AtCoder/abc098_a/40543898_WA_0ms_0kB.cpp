#include <bits/stdc++.h>
using namespace std;
int main ()
{
    int a,b;
    cin>>a>>b;
    int k = abs(a)+abs(b);
    int l = a*b;
    if(k>l)
    {
        cout<<k<<endl;
    }
    else
    {
        cout<<l<<endl;
    }
}
