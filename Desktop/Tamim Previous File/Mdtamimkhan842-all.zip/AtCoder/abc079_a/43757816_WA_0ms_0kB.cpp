#include <bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    cin >> s;
    int len = s.size();
    int c = 1, k = 1;
    for (int i = 0; i < len; i++)
    {
        if (s[i] == s[i + 1])
        {
            c++;
        }
        else
        {
            if (k < c)
            {
                k = c;
            }
            c = 0;
        }
    }

    if (c > 2 || k > 2)
        cout << "Yes" << endl;
    else
        cout << "No" << endl;
}