#include <bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    cin >> s;
    int len = s.size();
    int c = 0;
    for (int i = 0; i < len; i++)
    {
        if (s[i] == s[i + 1])
            c++;
    }
    // cout << c << endl;
    if (len - 1 == c || len - 2 == c)
        cout << "Yes" << endl;
    else
        cout << "No" << endl;
}