#include <bits/stdc++.h>
using namespace std;
int main ()
{
    int a, b,c;
    cin>>a>>b>>c;
    if (a<=b && a<=c || b<=a && b<=c)
    {
        int result = a+b;
        cout<<result<<endl;
    }
    else if (b<=a && b<=c || c<=a && c<=b)
    {
        int result = b+c;
        cout<<result<<endl;
    }

    else
    {
        int result = a+c;
        cout<<result<<endl;
    }



}
