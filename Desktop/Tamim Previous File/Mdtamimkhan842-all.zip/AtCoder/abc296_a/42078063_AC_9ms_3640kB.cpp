#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    string s;
    cin >> s;
    int c = 0, k = 0;
    if (t == 1)
    {
        cout << "Yes" << endl;
    }
    else if (t % 2 != 0)
    {
        for (int i = 0; i < t; i++)
        {
            if (s[i] == 'M' && s[i + 1] == 'F' && s[i + 2] == 'M')
            {
                c++;
            }
            else if (s[i] == 'F' && s[i + 1] == 'M' && s[i + 2] == 'F')
            {
                k++;
            }
        }
        int p = t / 2;
        if (p == c || p == k)
        {
            cout << "Yes" << endl;
        }
        else
        {
            cout << "No" << endl;
        }
    }

    else
    {

        for (int i = 0; i < t; i++)
        {
            if (s[i] == 'M' && s[i + 1] == 'F')
            {
                c++;
            }
            else if (s[i] == 'F' && s[i + 1] == 'M')
            {
                k++;
            }
        }
        int p = t / 2;
        if (p == c || p == k)
        {
            cout << "Yes" << endl;
        }
        else
        {
            cout << "No" << endl;
        }
    }
}