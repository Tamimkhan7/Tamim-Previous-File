#include <bits/stdc++.h>
using namespace std;
int main ()
{
    int x;
    cin>>x;
    for (int i=x; i>=0; i--)
    {
        cout<<i<<endl;
    }

    return 0;
}
