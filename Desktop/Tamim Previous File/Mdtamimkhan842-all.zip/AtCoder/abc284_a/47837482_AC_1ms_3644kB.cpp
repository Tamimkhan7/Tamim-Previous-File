#include <bits/stdc++.h>
using namespace std;
int main(){
    int t;cin>>t;
    vector<string>v;
    while(t--){
        string s;cin>>s;
        v.push_back(s);
    }
    reverse(v.begin(), v.end());
    for(auto x : v)cout<<x<<'\n';
}