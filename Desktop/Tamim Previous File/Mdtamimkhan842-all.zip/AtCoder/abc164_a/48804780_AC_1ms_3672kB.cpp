#include <bits/stdc++.h>
using namespace std;

int32_t main()
{
    int s, w;
    cin >> s >> w;
    if (w >= s)
        cout << "unsafe" << '\n';
    else
        cout << "safe" << '\n';
}