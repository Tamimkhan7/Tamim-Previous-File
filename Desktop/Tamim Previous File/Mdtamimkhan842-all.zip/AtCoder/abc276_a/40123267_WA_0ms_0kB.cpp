#include <bits/stdc++.h>
#include <cstring>
#include <stdio.h>
#include <string>
using namespace std;
int main ()
{
    int c=0, result2;
    char s[1000];
    cin>>s;
    int result = strlen(s);
    for (int i = result-1; i>=0; i--)
    {
        c++;
        if (c==result)
        {
            cout<<"-1"<<endl;
        }
        else if (s[i] == 'a')
        {
            result2 = result -c;
            break;
        }
    }
    if (c==result)
    {

    }
    else
    {
        cout<<result2+1<<endl;
    }

    return 0;
}
