#include <bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    cin>>s;
    int len = s.size();
    //cout<<len<<endl;
    int c=0;
    for(int i=len-1; i>=0; i--)
    {
        if(s[i] <= 'a')
        {
            c++;
            //break;
        }
    }

    if(c==len)
    {
        cout<<c<<endl;
    }
    else if(c !=0)
    {
        int k = (len-c)+1;
        cout<<k<<endl;
    }
    else
    {
        cout<<-1<<endl;
    }

}
