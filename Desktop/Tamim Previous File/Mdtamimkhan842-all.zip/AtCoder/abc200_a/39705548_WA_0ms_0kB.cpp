#include <iostream>
using namespace std;
int main ()
{
    long long int N;
    cin>>N;
    int result = (N/100);
    cout<<result;

    return 0;
}
