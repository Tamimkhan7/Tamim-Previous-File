#include <iostream>
using namespace std;
int main ()
{
int N;
cin>>N;
int result = N/100;
cout<<result<<endl;

return 0;
}
