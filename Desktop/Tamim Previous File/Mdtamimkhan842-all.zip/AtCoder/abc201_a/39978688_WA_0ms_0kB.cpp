#include <bits/stdc++.h>
#include <stdlib.h>
using namespace std;
int main ()
{
    int a, b,c;
    cin>>a>>b>>c;
    int result = abs(c-b);
    int result2 = abs(b-a);
    int result3 = result2-result;
    if (result== result3)
    {
        cout<<"Yes"<<endl;
    }
    else
    {
        cout<<"No"<<endl;
    }



    return 0;
}
