#include <bits/stdc++.h>
using namespace std;
#define ll long long int

int main()
{
    int n;
    cin>>n;
    int a[n];
    int mn =1e6;
    for(int i=0; i<n; i++)
    {
        cin>>a[i];
        mn = min(mn, a[i]);
    }
    int x =n;
    n--;
    int j=mn;
    while(1)
    {
        int ans=0;
        for(int i=0; i<x; i++)
        {
            if(a[i]%j==0)
            {
                ans++;
            }
        }
        if(ans>=2 && j>=2)
        {
            cout<<j<<'\n';
            return 0;
        }
        j++;
    }
}
